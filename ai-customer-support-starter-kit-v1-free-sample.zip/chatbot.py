"""
AI Customer Support Starter Kit v1 — Matching Engine (Sample)

A lightweight FAQ matching engine using stdlib only.
This is the same algorithm as the full kit — included so the sample runs standalone.

Source: Full kit includes this module + 10 FAQs + deployment guides.
"""
import json
import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Optional


@dataclass
class FAQEntry:
    id: str
    question_variants: list[str]
    answer: str
    category: str = "general"
    confidence: float = 0.95


@dataclass
class ChatbotResponse:
    answer: str
    confidence: float
    source_id: Optional[str] = None
    source_category: Optional[str] = None
    matched_question: Optional[str] = None
    fallback: bool = False


class FAQChatbot:
    DEFAULT_FALLBACK = (
        "I'm sorry, I don't have information about that specific question. "
        "Please try rephrasing or contact us directly."
    )
    DEFAULT_MIN_CONFIDENCE = 0.4

    def __init__(self, kb_path=None, fallback_message=None, min_confidence=DEFAULT_MIN_CONFIDENCE):
        self._kb_path = Path(kb_path) if kb_path else Path(__file__).parent / "kb" / "faqs.json"
        self._fallback_message = fallback_message or self.DEFAULT_FALLBACK
        self._min_confidence = min_confidence
        self._faqs: list[FAQEntry] = []
        self._knowledge_base = []
        self._business_context = self._load_business_context()
        self.load_knowledge_base()

    def _load_business_context(self) -> dict:
        context_path = self._kb_path.parent / "context.json"
        defaults = {
            "business_name": "Demo Business",
            "business_type": "Retail Store",
            "phone": "(555) 123-4567",
            "email": "info@demo.example.com",
            "address": "123 Main St, Springfield",
            "website": "https://demo.example.com",
        }
        if context_path.exists():
            try:
                with open(context_path, encoding="utf-8") as f:
                    defaults.update(json.load(f))
            except (json.JSONDecodeError, OSError):
                pass
        return defaults

    def load_knowledge_base(self) -> None:
        with open(self._kb_path, encoding="utf-8") as f:
            raw = json.load(f)
        self._faqs = [
            FAQEntry(
                id=item.get("id", ""),
                question_variants=item.get("question_variants", []),
                answer=item.get("answer", ""),
                category=item.get("category", "general"),
                confidence=item.get("confidence", 0.95),
            )
            for item in raw
        ]
        self._knowledge_base = raw

    @property
    def faq_count(self) -> int:
        return len(self._faqs)

    def get_business_context(self) -> dict:
        return self._business_context.copy()

    def get_faqs(self) -> list:
        return self._knowledge_base

    @staticmethod
    def _preprocess(text: str) -> str:
        text = text.lower().strip()
        text = re.sub(r"[^\w\s]", " ", text)
        text = re.sub(r"\s+", " ", text)
        return text

    _STOPWORDS = frozenset({
        "what", "are", "you", "do", "i", "a", "the", "is", "at", "in",
        "for", "to", "of", "and", "or", "an", "this", "that", "it",
        "can", "will", "would", "should", "how", "when", "where",
        "your", "with", "on", "by", "from", "up", "out", "about",
        "me", "my", "we", "our", "us", "has", "have", "had", "been",
        "was", "were", "be", "being", "not", "no", "so", "if",
    })

    def _similarity(self, a: str, b: str) -> float:
        a_clean = self._preprocess(a)
        b_clean = self._preprocess(b)
        tokens_a = set(a_clean.split())
        tokens_b = set(b_clean.split())
        content_a = tokens_a - self._STOPWORDS
        content_b = tokens_b - self._STOPWORDS
        jaccard = 0.0
        if content_a or content_b:
            union = content_a | content_b
            intersection = content_a & content_b
            if union:
                jaccard = len(intersection) / len(union)
        seq_ratio = SequenceMatcher(None, a_clean, b_clean).ratio()
        return 0.7 * jaccard + 0.3 * seq_ratio

    def _find_best_match(self, query: str) -> tuple[Optional[FAQEntry], Optional[str], float]:
        best_entry, best_variant, best_score = None, None, 0.0
        for entry in self._faqs:
            for variant in entry.question_variants:
                score = self._similarity(query, variant)
                if score > best_score:
                    best_score = score
                    best_entry = entry
                    best_variant = variant
        return best_entry, best_variant, best_score

    def ask(self, query: str) -> ChatbotResponse:
        if not query or not query.strip():
            return ChatbotResponse(
                answer="I'm here to help! Please ask me a question about our business.",
                confidence=0.0,
                fallback=True,
            )
        if len(query.strip()) < 2:
            return ChatbotResponse(
                answer="I'm sorry, I didn't catch that. Could you rephrase?",
                confidence=0.0,
                fallback=True,
            )
        entry, matched_variant, score = self._find_best_match(query)
        if entry is None or score < self._min_confidence:
            return ChatbotResponse(
                answer=self._fallback_message,
                confidence=0.0,
                fallback=True,
            )
        effective_confidence = min(score * entry.confidence, 1.0)
        return ChatbotResponse(
            answer=entry.answer,
            confidence=effective_confidence,
            source_id=entry.id,
            source_category=entry.category,
            matched_question=matched_variant,
            fallback=False,
        )


if __name__ == "__main__":
    bot = FAQChatbot()
    print(f"Loaded {bot.faq_count} FAQs (sample)")
    test_queries = [
        "What time do you open?",
        "Can I return something?",
        "What is the meaning of life?",
    ]
    for q in test_queries:
        result = bot.ask(q)
        print(f"\nQ: {q}")
        print(f"A: {result.answer}")
        print(f"Match: {result.matched_question} | Confidence: {result.confidence:.2f} | Fallback: {result.fallback}")
