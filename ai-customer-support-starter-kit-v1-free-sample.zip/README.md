# AI Customer Support Starter Kit v1 — FREE SAMPLE

## What This Is
A small working example of the FAQ chatbot matching engine. Contains 3 sample FAQs and runs the same algorithm as the full kit.

## What This Is NOT
- This is NOT the full product. The full kit has 10 FAQs, a restaurant example, and complete deployment guides.
- This is NOT generative AI. It only answers from the 3 pre-written FAQs in this file.

## Try It
```bash
pip install flask
python server.py
# Open http://localhost:5000
```

## Interested in the Full Kit?
Email [your-email] with subject "AI Customer Support Kit" for purchase details ($5 one-time).

## Limitations (Same as Full Kit)
- FAQ-only: only answers questions in the knowledge base
- No AI generation (this is text matching, not LLM)
- No email/SMS notifications
- No analytics dashboard
- No admin panel
- Single language (English)