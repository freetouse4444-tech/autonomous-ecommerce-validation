"""
AI Customer Support Starter Kit v1 — FREE SAMPLE
A small working example. See the full kit at [product page link] for 10 FAQs + deployment guide.

This sample contains 3 FAQs and runs the same matching engine as the full kit.
No API keys required. Works offline with Python 3.8+ only.
"""
import os
from pathlib import Path

from flask import Flask, request, jsonify, render_template_string
from chatbot import FAQChatbot

BASE_DIR = Path(__file__)
KB_PATH = BASE_DIR / "kb" / "faqs.json"

bot = FAQChatbot(kb_path=str(KB_PATH))
print(f"Loaded {bot.faq_count} FAQs from sample")

app = Flask(__name__)

@app.route("/")
def index():
    context = bot.get_business_context()
    faqs = bot.get_faqs()
    return render_template_string("""
<!DOCTYPE html>
<html><head><title>{{ name }}</title></head>
<body style="font-family:sans-serif;max-width:600px;margin:40px auto;padding:20px">
  <h1>{{ name }} — AI Assistant (Sample)</h1>
  <p style="color:#666">Ask about: hours, returns, contact. This is a 3-FAQ sample.</p>
  <div id="chat" style="height:300px;border:1px solid #ddd;border-radius:8px;padding:10px;overflow-y:auto;margin:10px 0">
    <div style="background:#f5f5f5;padding:8px;border-radius:6px;margin:5px 0">I'm the demo bot. Ask me 3 questions.</div>
  </div>
  <input id="q" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px" placeholder="Type here...">
  <button onclick="ask()" style="background:#3b82f8;color:white;border:none;padding:8px 16px;border-radius:6px;margin-left:5px">Send</button>
  <p style="color:#999;font-size:0.8em;margin-top:10px">Sample only. Full kit has 10 FAQs + restaurant example.</p>
</body>
<script>
async function ask(){
  const q=document.getElementById('q').value;
  if(!q)return;
  const chat=document.getElementById('chat');
  chat.innerHTML+='<div style="text-align:right;margin:5px 0">'+q+'</div>';
  const r=await fetch('/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:q})});
  const d=await r.json();
  chat.innerHTML+='<div style="background:#f5f5f5;padding:8px;border-radius:6px;margin:5px 0">'+d.answer+'</div>';
  document.getElementById('q').value='';
  chat.scrollTop=chat.scrollHeight;
}
document.getElementById('q').addEventListener('keypress',e=>{if(e.key==='Enter')ask()});
</script>
""", name=context.get("business_name", "Demo"), )

@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(silent=True) or {}
    query = data.get("query", "")
    if not query or not query.strip():
        return jsonify({"answer": "Please ask a question.", "confidence": 0.0, "fallback": True})
    response = bot.ask(query)
    return jsonify({
        "answer": response.answer,
        "confidence": round(response.confidence, 4),
        "source_id": response.source_id,
        "matched_question": response.matched_question,
        "fallback": response.fallback,
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)